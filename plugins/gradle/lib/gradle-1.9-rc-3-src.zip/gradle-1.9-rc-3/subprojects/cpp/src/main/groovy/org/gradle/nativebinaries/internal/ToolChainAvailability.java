/*
 * Copyright 2013 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.gradle.nativebinaries.internal;

import java.io.File;

public class ToolChainAvailability {
    private String unavailableMessage;

    public ToolChainAvailability() {
        unavailableMessage = null;
    }

    public boolean isAvailable() {
        return unavailableMessage == null;
    }

    public String getUnavailableMessage() {
        return unavailableMessage;
    }

    public void mustExist(String toolName, File tool) {
        if (this.unavailableMessage == null) {
            if (tool == null) {
                this.unavailableMessage = String.format("%s cannot be found", toolName);
            } else if (!tool.exists()) {
                this.unavailableMessage = String.format("%s does not exist (%s)", toolName, tool);
            }
        }
    }

    public ToolChainAvailability unavailable(String unavailableMessage) {
        if (this.unavailableMessage == null) {
            this.unavailableMessage = unavailableMessage;
        }
        return this;
    }
}
