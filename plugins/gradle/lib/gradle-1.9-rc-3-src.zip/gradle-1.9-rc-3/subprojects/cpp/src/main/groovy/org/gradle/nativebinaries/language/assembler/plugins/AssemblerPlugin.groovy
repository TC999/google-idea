/*
 * Copyright 2011 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.gradle.nativebinaries.language.assembler.plugins
import org.gradle.api.Incubating
import org.gradle.api.Plugin
import org.gradle.api.internal.project.ProjectInternal
import org.gradle.nativebinaries.toolchain.plugins.ClangCompilerPlugin
import org.gradle.nativebinaries.toolchain.plugins.GccCompilerPlugin
import org.gradle.nativebinaries.toolchain.plugins.MicrosoftVisualCppPlugin
/**
 * A plugin for projects wishing to build native binary components from Assembly language sources.
 *
 * <p>Adds core tool chain support to the {@link AssemblerNativeBinariesPlugin}.</p>
 */
@Incubating
class AssemblerPlugin implements Plugin<ProjectInternal> {

    void apply(ProjectInternal project) {
        project.plugins.apply(MicrosoftVisualCppPlugin)
        project.plugins.apply(GccCompilerPlugin)
        project.plugins.apply(ClangCompilerPlugin)

        project.plugins.apply(AssemblerNativeBinariesPlugin)
    }
}