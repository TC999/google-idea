/*
 * Copyright 2013 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.gradle.internal.classloader;

import java.io.Serializable;

/**
 * An immutable description of a ClassLoader hierarchy that can be used to recreate the hierarchy in a different process.
 *
 * Subclasses should implement equals() and hashCode(), so that the spec can be used as a hashmap key.
 */
public abstract class ClassLoaderSpec implements Serializable {
    public static final ClassLoaderSpec SYSTEM_CLASS_LOADER = new SystemClassLoaderSpec();

    private static class SystemClassLoaderSpec extends ClassLoaderSpec {
        @Override
        public boolean equals(Object obj) {
            return obj != null && obj.getClass().equals(getClass());
        }

        @Override
        public String toString() {
            return "system";
        }

        @Override
        public int hashCode() {
            return 121;
        }
    }
}
