/*
 * Copyright 2013 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.gradle.nativecode.language.c.tasks

import org.gradle.api.Incubating
import org.gradle.api.tasks.WorkResult
import org.gradle.nativecode.base.internal.ToolChainInternal
import org.gradle.nativecode.language.base.internal.NativeCompileSpec
import org.gradle.nativecode.language.c.internal.DefaultCCompileSpec
import org.gradle.nativecode.language.base.tasks.AbstractNativeCompileTask

/**
 * Compiles C source files into object files.
 */
@Incubating
class CCompile extends AbstractNativeCompileTask {
    @Override
    protected NativeCompileSpec createCompileSpec() {
        new DefaultCCompileSpec()
    }

    @Override
    protected WorkResult execute(ToolChainInternal toolChain, NativeCompileSpec spec) {
        return toolChain.createCCompiler().execute(spec)
    }
}
