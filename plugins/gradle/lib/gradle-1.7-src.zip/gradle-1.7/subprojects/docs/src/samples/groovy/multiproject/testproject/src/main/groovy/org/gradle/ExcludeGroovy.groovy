class ExcludeGroovy {

}